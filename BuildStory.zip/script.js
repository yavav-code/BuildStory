function showPreview(type) {
  document.querySelector(".book-options").classList.add("hidden");
  const preview = document.getElementById("preview");
  preview.classList.remove("hidden");

  const left = document.querySelector(".left-page");
  const right = document.querySelector(".right-page");

  if (type === "regular") {
    left.textContent = "Chapter 1";
    right.textContent = "Once upon a time...";
  } else if (type === "comic") {
    left.textContent = "Comic Scene 1";
    right.textContent = "💥 Boom! Action!";
  } else if (type === "text") {
    left.textContent = "Text Page A";
    right.textContent = "Text Page B";
  }
}

function goBack() {
  document.getElementById("preview").classList.add("hidden");
  document.querySelector(".book-options").classList.remove("hidden");
}
